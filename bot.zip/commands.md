# build for lambda


```bash
pip install \
--platform manylinux2014_x86_64 \
--target=site-packages \
--implementation cp \
--python-version 3.10.14 \
--only-binary=:all: --upgrade \
python-telegram-bot python-dotenv PyPDF2 reportlab openai
```